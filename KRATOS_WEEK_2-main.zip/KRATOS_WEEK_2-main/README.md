# KRATOS_WEEK_2
HEY!!

**Assignment 1**
I have submitted the jupyter notebook.

**Assignment 2**
I have submitted the jupyter notebook, the picture I used and the picture I saved
picture used is named "smarties.png"
picture saved is named "smarties_save.png"

**Assignment 3**
There are 2 pictures I used 
named
**"hogwarts.jpg" and "color.jpg"**

the saved images are **hogwarts_new.png** and **color_new.png**
I have also uploaded the two graphs

**Cheers!**


