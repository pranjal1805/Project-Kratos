# WEEK_3
**HELLO THERE**
I have uploaded the Jupyter notebook.<br />
I watched a course to help me in this assignment <br />
In the course, they used the imutils library, but this wasn't installed on my system so I downloaded it.

If there are some changes/feedback **can I get one week to implement it?** 

This week the both the assignments were a bit tough 😅

**Cheers!**
