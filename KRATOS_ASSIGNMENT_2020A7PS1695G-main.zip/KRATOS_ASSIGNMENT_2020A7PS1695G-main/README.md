# KRATOS_ASSIGNMENT_2020A7PS1695G
Hey there!<br />
I am **Pranjal Parashar(2020A7PS1695),** I have uploaded both the compulsory assignments in this repository. <br />
The first assignment has 2 files:<br />
1)First a .ipynb file(jupyter notebook)<br />
2)and I saved the numpy array as a new photo titled **"new_save.jpg"**<br />

The **Compulsory Assignment 2** was a hackerrank challenge.<br />
I have clicked the screenshots of the challenges as solved and uploaded it in a folder.<br />

I have also uploaded these links on the Google Classroom.<br />

Cheers!
